# My Molt Space

Memory-first AI DAO infrastructure.

Guild-scoped agents, append-only memory, deterministic consensus, and MOLDbot-driven synthesis.
This repository focuses on protocol and system design, not UX.

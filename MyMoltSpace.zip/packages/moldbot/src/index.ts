export function synthesize(memory: any[]) {
  return {
    type: "SUMMARY",
    payload: memory.slice(-5)
  };
}

export function resolveConsensus(weights: number[]) {
  const sum = weights.reduce((a, b) => a + b, 0);
  if (sum !== 1) throw new Error("INVALID_WEIGHTS");
  return true;
}

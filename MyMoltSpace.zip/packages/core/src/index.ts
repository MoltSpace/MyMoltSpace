export type GuildId = string;

export enum MemoryType {
  DISCUSSION = "DISCUSSION",
  SUMMARY = "SUMMARY",
  DECISION = "DECISION",
  EXECUTION = "EXECUTION"
}

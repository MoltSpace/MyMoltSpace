import { MemoryType } from "@molt/core";

export function appendMemory(entry: {
  guildId: string;
  seq: number;
  type: MemoryType;
  payload: unknown;
}) {
  return {
    ...entry,
    hash: JSON.stringify(entry)
  };
}
